# 0x00 - AirBnB Clone - Models - Engine
#### Directory: AirBnB_clone/models/engine
#### Project provided by Holberton School NHV

## Description
In this directory, students handle the *FileStorage* class, as well as the __objects dictionary through saving, reloading, and populating a new dictionary.

## Project Directories and Files
Names | Descriptions
----- | ----------------
file_storage.py | Class containing the handling of saving, reloading and creating a new dictionary

#### Authors
Written for HolbertonNHV by Michelle Giraldo and Kathleen McKiernan
