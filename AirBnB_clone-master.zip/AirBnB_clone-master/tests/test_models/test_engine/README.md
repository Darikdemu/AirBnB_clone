# 0x00 - AirBnB Clone - Tests - Test Models - Test Engine
#### Directory: AirBnB_clone/tests/test_models/test_engine
#### Project provided by Holberton School NHV

## Description
In this directory, students build the individual python test file to check for proper execution of the file_storage functions.

## Project Directories and Files

Names | Descriptions
----- | -------------------
test_file_storage.py | Unittest for proper execution of file_storage.py

#### Authors
Written for HolbertonNHV by Michelle Giraldo and Kathleen McKiernan
