# 0x00 - AirBnB Clone - Tests
#### Directory: AirBnB_clone/tests
#### Project provided by Holberton School NHV

## Description
In this directory, students create a collection of python test files in an initialized dictionary to check for the console's success.

## Project Directories and Files

Names | Descriptions
----- | -------------------
test_models | *Directory* containing all unittest files

#### Authors
Written for HolbertonNHV by Michelle Giraldo and Kathleen McKiernan
